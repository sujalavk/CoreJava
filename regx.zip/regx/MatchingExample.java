
package regx;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatchingExample { 
    public static void main(String[] args){
        String email = "georgewashington@example.com";
        Pattern p1=Pattern.compile("(^[a-z1-9]*)\\@([a-z]*)\\.([a-zA-Z]*)");
        //Pattern p1 = Pattern.compile("(\\S+?)\\@(\\S+)\\.(\\S+?)");
        Matcher m1 = p1.matcher(email);
        if (m1.find()){
            System.out.println("First: " + m1.group(1));
            System.out.println("Last: " + m1.group(2)); 
            System.out.println("Domain: " + m1.group(3)); 
            System.out.println("Everything Matched: " + m1.group(0));
        }
        else
        	System.out.println("not matched");
    }
}
