package regx;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternExample {
    public static void main(String[] args){
        String t = "It was wts the best of times";
    
        Pattern p = Pattern.compile("w.s");//. any character
        Matcher mat = p.matcher(t);
    
       while (mat.find()) 
        { 
            System.out.println(mat.group()+" found at "+mat.start() ); 
          
        }
    }
}
