package regx;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CustomCharClassExamples {
    public static void main(String[] args) {
        String t = "was";
        String t1 = "It wds happy times";
        Pattern p1 = Pattern.compile("w[a-e]s");
        Matcher m1 = p1.matcher(t);
        boolean b=m1.matches();
        
        	System.out.println("matched");
        
        Pattern p2 = Pattern.compile("w[a-c[f-k]]s");
        Matcher m2 = p2.matcher(t1);
        while (m2.find())
        { System.out.println("Found: " + m2.group());
        }

        Pattern p3 = Pattern.compile("t[^eou]mes");
        Matcher m3 = p3.matcher(t1);
        while (m3.find())
        
        { 
        	System.out.println("Found: " + m3.group());
        }
    }
}
