package regx;

import java.util.regex.Pattern;

public class Demo {
	 public static void main(String args[]) 
	    { 
	        // Following line prints "true"  
		 boolean flag;
		 flag=Pattern.matches("se.*k","sek"); 
                
	        System.out.println (flag); 
	  
	        // Following line prints "false" 
	   	  flag=Pattern.matches("seek*","seekkkfor");
	        System.out.println (flag); 
}
}
