import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class StreamDemo {
	public static void main(String[] args) {
		int i=0;
		
		char c;
		//try with resource 
			try (FileInputStream in=new FileInputStream("D:\\b190126\\Demo.txt"))
			{
			
				while((i=in.read())!=-1)
				{ 
					c=(char)i;
					System.out.print(c);
					
				}
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		
			
		}

}
