import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class OutSTReamDemo {
	public static void main(String[] args) {
	int i; 
	String s="Hello welcome to niit";
	byte b[]=s.getBytes();
	try
	(FileOutputStream out=new FileOutputStream("D:\\b190126\\output.txt");)
		{
		
			for(i=0;i<b.length;i++)	
			{ 
				/*char c=(char)b[i];
				System.out.print(c);*/
				out.write(b[i]);
				
				
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
