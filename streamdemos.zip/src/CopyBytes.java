import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyBytes {
public static void main(String[] args) {
	int i=0;
	
	char c;
	//try with resource 
		try (FileInputStream in=new FileInputStream("D:\\b190126\\Demo.txt");
				FileOutputStream out=new FileOutputStream("D:\\b190126\\output.txt"))
		{
		
			while((i=in.read())!=-1)
			{ 
				out.write(i);
				/*c=(char)i;
				System.out.print(c);*/
				
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	
		
}
}
