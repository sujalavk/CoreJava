import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class ObjectStreamDemo {
	public static void main(String[] args) throws FileNotFoundException {
		
		Student s =new Student(1,"neema");
		FileOutputStream fo=new FileOutputStream("E:\\student.txt");
		FileInputStream fi=new FileInputStream("E:\\student.txt");
	try {
		ObjectOutputStream out=new ObjectOutputStream(fo);
		out.writeObject(s);
		
	  ObjectInputStream in=new ObjectInputStream(fi);
	   try {
		Student s1= (Student) in.readObject();
		System.out.println(s1);
	} catch (ClassNotFoundException e) {
	
		e.printStackTrace();
	}
	  
		
		
	} catch (IOException e) {
		
		e.printStackTrace();
	}
	}

}
