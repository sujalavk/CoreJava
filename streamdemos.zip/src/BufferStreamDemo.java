import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;

public class BufferStreamDemo {
	public static void main(String[] args) {
		

	int i=0;
	
	char c;
	//try with resource 
		try (FileInputStream in=new FileInputStream("D:\\Term2Demos\\StreamDemo\\src\\input.txt");
				BufferedInputStream bin=new BufferedInputStream(in))
		{
		
			while((i=bin.read())!=-1)
			{ 
				c=(char)i;
				System.out.print(c);
				
			}
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	
}}

