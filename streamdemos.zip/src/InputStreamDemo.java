import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class InputStreamDemo {

	public static void main(String[] args) {
		int b;
		char c;
		try {
			FileInputStream fi = new FileInputStream("E:\\new.txt");//inputstream

			FileOutputStream fo = new FileOutputStream("E:\\output.txt");//outputstream

			//Reading from file
			while ((b = fi.read()) != -1)
				//System.out.print((char) b);//output to console
				fo.write(b);//output to file
			System.out.println("File is written");
			

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

}
