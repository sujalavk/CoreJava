
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CharStreamCopyTest {

	public static void main(String[] args) {
		int count = 0,read=0;
		char[] c = new char[128]; int cLen = c.length;
		// Example use of characterStream methods
		try (FileReader fr = new FileReader("E:\\new.txt");
				FileWriter fw = new FileWriter("D:\\ouput.txt")) {
					
					while ((read = fr.read(c)) != -1) {
						
						if (read < cLen) {
							fw.write(c, 0, read);
							fw.write("end of progarm");
						}
						
						else fw.write(c);
						count += read;
					}
					System.out.println("Wrote: " + count + " characters.");   
				} catch (FileNotFoundException f) {
					System.out.println("File not found: " + f);
				} catch (IOException e) {
					System.out.println("IOException: " + e);
				}
	}
}