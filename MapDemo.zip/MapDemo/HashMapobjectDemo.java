package MapDemo;

public class HashMapobjectDemo {
	public static void main(String[] args) {
		
	}

}
