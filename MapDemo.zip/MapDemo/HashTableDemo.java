package MapDemo;

import java.util.Hashtable;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class HashTableDemo {

	public static void main(String[] args) {
		Hashtable<String,Integer> m=new Hashtable<>();
		m.put("banglore",80);
		m.put("mysore",37);
		m.put("hubli",836);
		m.put("tumkur",835);
		m.put("chennai",835);
   // m.put(null, 99);//null pointer exception
		//m.put(null, 89);
	//	m.put("badami", null);//null pointer exception
	//	m.put("dharwad", null);
		System.out.println("std code of hubli:"+m.get("hubli"));
		
		Set<String> keys=m.keySet();
		for(String k:keys)
		{
			System.out.println("Key: "+k+ "  value: "+m.get(k));
		}
		
		

}
}
