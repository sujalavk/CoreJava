package MapDemo;

import java.util.*;

public class HashMapDemo {

	public static void main(String[] args) {
	Map<String,Integer> m=new HashMap<>();
	m.put("banglore",80);
	m.put("mysore",37);
	m.put("hubli",836);
	m.put("tumkur",835);
	m.put("chennai",835);
	m.put(null, 99);//null pointer exception if Tree map
	//m.put(null, 89);
	m.put("badami", null);
	m.put("dharwad", null);
	System.out.println("std code of hubli:"+m.get("hubli"));
	//first method
	Set<String> keys=m.keySet();
	for(String k:keys)
	{
		System.out.println("Key: "+k+ "  value: "+m.get(k));
	}
	m.remove("mysore");
	System.out.println("=====using MAP ENTRY");
	//print map entries using Map.Entry
	
	for(Map.Entry<String,Integer> mp:m.entrySet())
	{
		System.out.println(mp.getKey()+" " +mp.getValue());
	}
	
	
	
	}

}
