package comparabledemos;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class SortingDemo {

	public static void main(String[] args) {
		Student s1=new Student(11,"raju");
		Student s2=new Student(22,"smita");
		Student s3=new Student(21,"geeta");
		Student s4=new Student(12,"seeta");
		Student s5=new Student(14,"neeta");
		ArrayList<Student> list = new ArrayList<>();
		list.add(s1);
		list.add(s2);
		list.add(s3);
		list.add(s4);
		list.add(s5);
		Collections.sort(list);
	
		Iterator it = list.iterator();
		while (it.hasNext())
			System.out.println(it.next());
		
	}

}
