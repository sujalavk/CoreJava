import java.util.*;
public class QueueDemo {

	public static void main(String[] args) {
		Deque<String> queue=new ArrayDeque<>() ;
		queue.add("apple");
		queue.add("mango");
		queue.add("orange");
		queue.add("banana");
		queue.add("banana");
		queue.addFirst("kiwi");
		queue.removeLast();
		System.out.println("Retrived elements after peekFirst:"+queue.peekFirst());
		System.out.println("Retrived elements after getLast:"+queue.getLast());
	     
		//queue.add(null);//runtime error:NullPointer Exception
		Iterator it = queue.iterator();
		while (it.hasNext())
			System.out.println(it.next());
		queue.remove();
		System.out.println("Ater remove");
		 it = queue.iterator();
		while (it.hasNext())
			System.out.println(it.next());
		queue.clear();
		System.out.println("Retrived elements after peekFirst:"+queue.peekFirst());//null
		System.out.println("Retrived elements after getLast:"+queue.getFirst());//NoSuchElementException
	
		
		
	}

}
