import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueDemo {

	public static void main(String[] args) {
		Queue<Integer> queue=new PriorityQueue<>() ;
		System.out.println("size:"+queue.size());
		queue.add(11);
		queue.add(12);
		queue.add(4);
		queue.add(8);
		queue.add(9);
		queue.add(9);
		queue.add(1);
	//	queue.add(null);//nullpointerexceprion
		Iterator<Integer> it = queue.iterator();
		while (it.hasNext())
			System.out.println(it.next());
		System.out.println("size:"+queue.size());
		

	}

}
