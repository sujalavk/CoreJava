import java.util.*;

public class MethodsDemo {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<>();
		list.add(10);
		list.add(80);
		list.add(20);
		list.add(30);
		list.add(30);
		list.add(null);
		// first method

		for (Integer i : list) {
			System.out.println(i);
		}

       // Collections.sort(list);
		System.out.println("After sorting ");
		Iterator it = list.iterator();
		while (it.hasNext())
			System.out.println(it.next());
	//	System.out.println("Max:"+Collections.max(list));
	

	}

}
