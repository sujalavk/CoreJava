
public class Student {
	int id;
	String name;
	public Student(int id, String name) {
		
		this.id = id;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	@Override
	public int hashCode() {
		
		return id;
	}
	@Override
	public boolean equals(Object obj) {
      Student s=(Student)obj;
		if(this.id==s.id)
		{
			return true;
		}
		else
			return false;
	}
	
	

}
