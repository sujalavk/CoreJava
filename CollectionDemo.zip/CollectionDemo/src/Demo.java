
public class Demo {

	public static void main(String[] args) {
		Student s1=new Student(1,"raju");
		Student s2=new Student(2,"raju");
		System.out.println("S1 hascode:"+s1.hashCode());
		System.out.println("S2 hascode:"+s2.hashCode());
		if(s1.equals(s2))
			System.out.println("Both are equal");
		else
			System.out.println("Both are not equal");
		System.out.println("S1:"+s1.toString());
		System.out.println("S2:"+s2);
	}

}
