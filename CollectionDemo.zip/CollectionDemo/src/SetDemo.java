import java.util.*;

public class SetDemo {
	public static void main(String[] args) {


		Set<Integer> set = new TreeSet<>();
        set.add(56);
		set.add(80);
		set.add(20);
		set.add(30);
		set.add(30);
		//set.add(null);//run time error NullPointer Exception
		System.out.println("Number of values :"+set.size());
		System.out.println("Set values are");
		Iterator it = set.iterator();
		while (it.hasNext())
			System.out.println(it.next());
		


	}
}
